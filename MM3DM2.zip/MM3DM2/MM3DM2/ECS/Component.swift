//
//  Component.swift
//  MM3DM2
//
//  Created by Mohammad Jeragh on 08/07/2023.
//

import Foundation
protocol Component {
   static var componentType: String { get } //I got this from bing
}
