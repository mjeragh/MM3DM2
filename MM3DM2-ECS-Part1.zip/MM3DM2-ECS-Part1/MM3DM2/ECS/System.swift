//
//  System.swift
//  MM3DM2
//
//  Created by Mohammad Jeragh on 10/07/2023.
//

import Foundation
protocol System {
    
}
