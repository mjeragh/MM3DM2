//
//  MM3DM2App.swift
//  MM3DM2
//
//  Created by Mohammad Jeragh on 20/06/2023.
//

import SwiftUI

@main
struct MM3DM2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
